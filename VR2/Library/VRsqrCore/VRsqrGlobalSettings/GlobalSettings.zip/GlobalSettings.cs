﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GlobalSettingsPlugin
{
    public class GlobalSettings : MonoBehaviour
    {

        public static string DataPath;
        public string dataPath;

        public static string SubjectsStr;
        public string subjectsStr;

        // Use this for initialization
        void Start()
        {
            updateVars();
        }

        // Update is called once per frame
        void Update()
        {

        }

        void OnValidate()
        {
            updateVars();
        }

        void updateVars()
        {
            SubjectsStr = subjectsStr;
            DataPath = dataPath;
        }
    }
}
